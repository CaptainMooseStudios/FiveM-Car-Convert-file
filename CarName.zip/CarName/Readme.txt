Open OpenIV Than - click on tools - than asi manager than install all options

then click on mods folder place car folder in there with DLC file than make a new folder "CarName" Then inport a __resource.lua then make 2 folders called "stream" "data"

now click on the dlc folder - then open "data" then drag all files into "CarName" the open "data" then drag all data files into there 

now go back to the dlc folder and click on "x64" if you see a folder called "VehicleMods" Places thos into the "stream" folder in the "CarName" Folder

then drag all files from "Vehicles.rpf" to the "stream" folder too

then your all done

if you have any issues join https://discord.gg/uxPhWgSFAh to get support!



Made By: CaptainMoose

11:31 AM
8/1/22